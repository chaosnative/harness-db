# Enterprise ChaosHub

This repository hosts the HCE Faults and experiments manifests. A complete set of faults are bundled into different categories. The different categories are mentioned below:

<table>
  <tr>
    <th>Category</th>
    <th>Description</th>
  </tr>
  <tr>
    <td>Kubernetes</td>
    <td>It contains different pod and node level Kubernetes chaos faults.</td>
  </tr>
  <tr>
    <td>AWS</td>
    <td>It contains all the chaos faults for AWS platform.</td>
  </tr>
  <tr>
    <td>VMware</td>
    <td>It contains the chaos faults for VMware platform.</td>
  </tr>
  <tr>
    <td>Azure</td>
    <td>It contains the chaos faults for Azure platform.</td>
  </tr>
  <tr>
    <td>GCP</td>
    <td>It contains the chaos faults for GCP platform.</td>
  </tr>
  <tr>
    <td>Kube Resilience</td>
    <td>It contains the chaos faults that stress test the Kubernetes platform.</td>
  </tr>
  <tr>
    <td>Load</td>
    <td>It contains the loadgen chaos faults.</td>
  </tr>
</table>
